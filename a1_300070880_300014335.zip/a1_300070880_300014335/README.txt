Student name: Nick Bailuc, Illia Negovora
Student number: 300014335, 300070880
Course code: ITI1121
Lab section: C-02, C-01

Assignment number 2: 

Question 1: an implememnattion of TicTacToe game on
NxM board between player and computer (which plays random avaliable cells).

Quastion 2: an implementation of all possible games generator.
Such generator creates a list of all possible games at every possible games
untill no more game can be played (all are won or draw)

Question 3: similarly to question 2 it creates list of all possible games,
however only for 3x3 matrix and new implemenatation takes in consideration
the symmetry of boards


