interface Player
{
	public void play(TicTacToeGame game);
}
